-- MySQL dump 10.13  Distrib 8.0.44, for macos15.4 (arm64)
--
-- Host: localhost    Database: game_platform
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `algo_config`
--

DROP TABLE IF EXISTS `algo_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `algo_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `alpha` double NOT NULL,
  `beta` double NOT NULL,
  `decay_lambda` double NOT NULL,
  `weight_download` double NOT NULL,
  `weight_follow` double NOT NULL,
  `weight_review` double NOT NULL,
  `weight_like` double NOT NULL,
  `weight_comment` double NOT NULL,
  `top_k` int NOT NULL,
  `refresh_hours` int NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `algo_config`
--

LOCK TABLES `algo_config` WRITE;
/*!40000 ALTER TABLE `algo_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `algo_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add crontab',6,'add_crontabschedule'),(22,'Can change crontab',6,'change_crontabschedule'),(23,'Can delete crontab',6,'delete_crontabschedule'),(24,'Can view crontab',6,'view_crontabschedule'),(25,'Can add interval',7,'add_intervalschedule'),(26,'Can change interval',7,'change_intervalschedule'),(27,'Can delete interval',7,'delete_intervalschedule'),(28,'Can view interval',7,'view_intervalschedule'),(29,'Can add periodic task',8,'add_periodictask'),(30,'Can change periodic task',8,'change_periodictask'),(31,'Can delete periodic task',8,'delete_periodictask'),(32,'Can view periodic task',8,'view_periodictask'),(33,'Can add periodic tasks',9,'add_periodictasks'),(34,'Can change periodic tasks',9,'change_periodictasks'),(35,'Can delete periodic tasks',9,'delete_periodictasks'),(36,'Can view periodic tasks',9,'view_periodictasks'),(37,'Can add solar event',10,'add_solarschedule'),(38,'Can change solar event',10,'change_solarschedule'),(39,'Can delete solar event',10,'delete_solarschedule'),(40,'Can view solar event',10,'view_solarschedule'),(41,'Can add clocked',11,'add_clockedschedule'),(42,'Can change clocked',11,'change_clockedschedule'),(43,'Can delete clocked',11,'delete_clockedschedule'),(44,'Can view clocked',11,'view_clockedschedule'),(45,'Can add 用户',12,'add_user'),(46,'Can change 用户',12,'change_user'),(47,'Can delete 用户',12,'delete_user'),(48,'Can view 用户',12,'view_user'),(49,'Can add 用户操作记录',13,'add_useroperation'),(50,'Can change 用户操作记录',13,'change_useroperation'),(51,'Can delete 用户操作记录',13,'delete_useroperation'),(52,'Can view 用户操作记录',13,'view_useroperation'),(53,'Can add 发行商',14,'add_publisher'),(54,'Can change 发行商',14,'change_publisher'),(55,'Can delete 发行商',14,'delete_publisher'),(56,'Can view 发行商',14,'view_publisher'),(57,'Can add 标签',15,'add_tag'),(58,'Can change 标签',15,'change_tag'),(59,'Can delete 标签',15,'delete_tag'),(60,'Can view 标签',15,'view_tag'),(61,'Can add 游戏',16,'add_game'),(62,'Can change 游戏',16,'change_game'),(63,'Can delete 游戏',16,'delete_game'),(64,'Can view 游戏',16,'view_game'),(65,'Can add 收藏',17,'add_collection'),(66,'Can change 收藏',17,'change_collection'),(67,'Can delete 收藏',17,'delete_collection'),(68,'Can view 收藏',17,'view_collection'),(69,'Can add 算法配置',18,'add_algoconfig'),(70,'Can change 算法配置',18,'change_algoconfig'),(71,'Can delete 算法配置',18,'delete_algoconfig'),(72,'Can view 算法配置',18,'view_algoconfig'),(73,'Can add 游戏每日指标',19,'add_gamemetricsdaily'),(74,'Can change 游戏每日指标',19,'change_gamemetricsdaily'),(75,'Can delete 游戏每日指标',19,'delete_gamemetricsdaily'),(76,'Can view 游戏每日指标',19,'view_gamemetricsdaily'),(77,'Can add 推荐记录',20,'add_recommendation'),(78,'Can change 推荐记录',20,'change_recommendation'),(79,'Can delete 推荐记录',20,'delete_recommendation'),(80,'Can view 推荐记录',20,'view_recommendation'),(81,'Can add 用户兴趣',21,'add_userinterest'),(82,'Can change 用户兴趣',21,'change_userinterest'),(83,'Can delete 用户兴趣',21,'delete_userinterest'),(84,'Can view 用户兴趣',21,'view_userinterest'),(85,'Can add 内容审核',22,'add_contentreview'),(86,'Can change 内容审核',22,'change_contentreview'),(87,'Can delete 内容审核',22,'delete_contentreview'),(88,'Can view 内容审核',22,'view_contentreview'),(89,'Can add 媒体资源',23,'add_mediaasset'),(90,'Can change 媒体资源',23,'change_mediaasset'),(91,'Can delete 媒体资源',23,'delete_mediaasset'),(92,'Can view 媒体资源',23,'view_mediaasset'),(93,'Can add 攻略',24,'add_strategy'),(94,'Can change 攻略',24,'change_strategy'),(95,'Can delete 攻略',24,'delete_strategy'),(96,'Can view 攻略',24,'view_strategy'),(97,'Can add 攻略收藏',25,'add_strategycollection'),(98,'Can change 攻略收藏',25,'change_strategycollection'),(99,'Can delete 攻略收藏',25,'delete_strategycollection'),(100,'Can view 攻略收藏',25,'view_strategycollection'),(101,'Can add 评论',26,'add_comment'),(102,'Can change 评论',26,'change_comment'),(103,'Can delete 评论',26,'delete_comment'),(104,'Can view 评论',26,'view_comment'),(105,'Can add 反馈',27,'add_feedback'),(106,'Can change 反馈',27,'change_feedback'),(107,'Can delete 反馈',27,'delete_feedback'),(108,'Can view 反馈',27,'view_feedback'),(109,'Can add 动态',28,'add_post'),(110,'Can change 动态',28,'change_post'),(111,'Can delete 动态',28,'delete_post'),(112,'Can view 动态',28,'view_post'),(113,'Can add 互动',29,'add_reaction'),(114,'Can change 互动',29,'change_reaction'),(115,'Can delete 互动',29,'delete_reaction'),(116,'Can view 互动',29,'view_reaction'),(117,'Can add 举报',30,'add_report'),(118,'Can change 举报',30,'change_report'),(119,'Can delete 举报',30,'delete_report'),(120,'Can view 举报',30,'view_report'),(121,'Can add 话题',31,'add_topic'),(122,'Can change 话题',31,'change_topic'),(123,'Can delete 话题',31,'delete_topic'),(124,'Can view 话题',31,'view_topic'),(125,'Can add 话题关注',32,'add_topicfollow'),(126,'Can change 话题关注',32,'change_topicfollow'),(127,'Can delete 话题关注',32,'delete_topicfollow'),(128,'Can view 话题关注',32,'view_topicfollow'),(129,'Can add 仪表盘缓存',33,'add_dashcardcache'),(130,'Can change 仪表盘缓存',33,'change_dashcardcache'),(131,'Can delete 仪表盘缓存',33,'delete_dashcardcache'),(132,'Can view 仪表盘缓存',33,'view_dashcardcache'),(133,'Can add 原始爬取数据',34,'add_rawcrawl'),(134,'Can change 原始爬取数据',34,'change_rawcrawl'),(135,'Can delete 原始爬取数据',34,'delete_rawcrawl'),(136,'Can view 原始爬取数据',34,'view_rawcrawl'),(137,'Can add 爬虫任务',35,'add_crawljob'),(138,'Can change 爬虫任务',35,'change_crawljob'),(139,'Can delete 爬虫任务',35,'delete_crawljob'),(140,'Can view 爬虫任务',35,'view_crawljob'),(141,'Can add 备份任务',36,'add_backupjob'),(142,'Can change 备份任务',36,'change_backupjob'),(143,'Can delete 备份任务',36,'delete_backupjob'),(144,'Can view 备份任务',36,'view_backupjob'),(145,'Can add 创作者激励',37,'add_incentive'),(146,'Can change 创作者激励',37,'change_incentive'),(147,'Can delete 创作者激励',37,'delete_incentive'),(148,'Can view 创作者激励',37,'view_incentive'),(149,'Can add 系统配置',38,'add_sysconfig'),(150,'Can change 系统配置',38,'change_sysconfig'),(151,'Can delete 系统配置',38,'delete_sysconfig'),(152,'Can view 系统配置',38,'view_sysconfig'),(153,'Can add 系统日志',39,'add_syslog'),(154,'Can change 系统日志',39,'change_syslog'),(155,'Can delete 系统日志',39,'delete_syslog'),(156,'Can view 系统日志',39,'view_syslog'),(157,'Can add 游戏截图',40,'add_gamescreenshot'),(158,'Can change 游戏截图',40,'change_gamescreenshot'),(159,'Can delete 游戏截图',40,'delete_gamescreenshot'),(160,'Can view 游戏截图',40,'view_gamescreenshot');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_jobs`
--

DROP TABLE IF EXISTS `backup_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint DEFAULT NULL,
  `error_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` datetime(6) NOT NULL,
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_jobs_status_6e12a054` (`status`),
  KEY `backup_jobs_started_at_8ff09276` (`started_at`),
  KEY `backup_jobs_status_a59bea_idx` (`status`,`started_at` DESC)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_jobs`
--

LOCK TABLES `backup_jobs` WRITE;
/*!40000 ALTER TABLE `backup_jobs` DISABLE KEYS */;
INSERT INTO `backup_jobs` VALUES (1,'failed','',NULL,'任务异常终止','2025-11-07 16:21:43.214673',NULL),(3,'success','/Volumes/GT/dijango400/backend/backups/backup_20251108_005255.sql.gz',21343,'','2025-11-07 16:52:55.243569','2025-11-07 16:52:55.338110'),(4,'success','/Volumes/GT/dijango400/backend/backups/backup_20251108_005441.sql.gz',21568,'','2025-11-07 16:54:41.935781','2025-11-07 16:54:42.040098'),(5,'success','/Volumes/GT/dijango400/backend/backups/backup_20251108_005632.sql.gz',21687,'','2025-11-07 16:56:32.064307','2025-11-07 16:56:32.204951'),(6,'running','',NULL,'','2025-11-07 17:00:34.313239',NULL);
/*!40000 ALTER TABLE `backup_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `game_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `collections_user_id_game_id_8fee1e86_uniq` (`user_id`,`game_id`),
  KEY `collections_created_at_739a4c07` (`created_at`),
  KEY `collections_user_id_d015b5_idx` (`user_id`,`created_at` DESC),
  KEY `collections_game_id_26c2d4_idx` (`game_id`,`created_at` DESC),
  CONSTRAINT `collections_game_id_aeead484_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`),
  CONSTRAINT `collections_user_id_155c6d5e_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
INSERT INTO `collections` VALUES (7,'2025-11-07 14:37:01.185785',1,2);
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int unsigned DEFAULT NULL,
  `like_count` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `game_id` bigint DEFAULT NULL,
  `parent_id` bigint DEFAULT NULL,
  `post_id` bigint DEFAULT NULL,
  `strategy_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_object_id_25f5f329` (`object_id`),
  KEY `comments_created_at_7df329d3` (`created_at`),
  KEY `comments_content_e0b24f_idx` (`content_type_id`,`object_id`,`created_at` DESC),
  KEY `comments_game_id_f5d593_idx` (`game_id`,`created_at` DESC),
  KEY `comments_strateg_5f4262_idx` (`strategy_id`,`created_at` DESC),
  KEY `comments_post_id_8fd787_idx` (`post_id`,`created_at` DESC),
  KEY `comments_parent__b79743_idx` (`parent_id`,`created_at` DESC),
  KEY `comments_user_id_a80af7_idx` (`user_id`,`created_at` DESC),
  CONSTRAINT `comments_content_type_id_ea0670fe_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `comments_game_id_46333f3d_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`),
  CONSTRAINT `comments_parent_id_d317363b_fk_comments_id` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`),
  CONSTRAINT `comments_post_id_67cfce36_fk_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `comments_strategy_id_84ad9fe7_fk_strategies_id` FOREIGN KEY (`strategy_id`) REFERENCES `strategies` (`id`),
  CONSTRAINT `comments_user_id_b8fd0b64_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `comments_chk_1` CHECK ((`object_id` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_reviews`
--

DROP TABLE IF EXISTS `content_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_reviews` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `auto_hit_keywords` json NOT NULL,
  `decision` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` longtext COLLATE utf8mb4_unicode_ci,
  `reviewed_at` datetime(6) NOT NULL,
  `reviewer_id` bigint DEFAULT NULL,
  `strategy_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `content_reviews_reviewed_at_78ff054a` (`reviewed_at`),
  KEY `content_rev_strateg_5cee15_idx` (`strategy_id`,`reviewed_at` DESC),
  KEY `content_rev_reviewe_a85ccc_idx` (`reviewer_id`,`reviewed_at` DESC),
  CONSTRAINT `content_reviews_reviewer_id_713c0e8e_fk_users_id` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`),
  CONSTRAINT `content_reviews_strategy_id_3c6d606e_fk_strategies_id` FOREIGN KEY (`strategy_id`) REFERENCES `strategies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_reviews`
--

LOCK TABLES `content_reviews` WRITE;
/*!40000 ALTER TABLE `content_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crawl_jobs`
--

DROP TABLE IF EXISTS `crawl_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crawl_jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `items_count` int NOT NULL,
  `error_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` datetime(6) NOT NULL,
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crawl_jobs_source_3b43a314` (`source`),
  KEY `crawl_jobs_status_4ec08835` (`status`),
  KEY `crawl_jobs_started_at_2a04e7e4` (`started_at`),
  KEY `crawl_jobs_source_2bd7ac_idx` (`source`,`started_at` DESC),
  KEY `crawl_jobs_status_b68ace_idx` (`status`,`started_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crawl_jobs`
--

LOCK TABLES `crawl_jobs` WRITE;
/*!40000 ALTER TABLE `crawl_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `crawl_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dash_card_cache`
--

DROP TABLE IF EXISTS `dash_card_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dash_card_cache` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `snapshot` json NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`),
  KEY `dash_card_cache_updated_at_98d3b4af` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dash_card_cache`
--

LOCK TABLES `dash_card_cache` WRITE;
/*!40000 ALTER TABLE `dash_card_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `dash_card_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_clockedschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_clockedschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_clockedschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clocked_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_clockedschedule`
--

LOCK TABLES `django_celery_beat_clockedschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_crontabschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_crontabschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_crontabschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `minute` varchar(240) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hour` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_of_week` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day_of_month` varchar(124) COLLATE utf8mb4_unicode_ci NOT NULL,
  `month_of_year` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(63) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_crontabschedule`
--

LOCK TABLES `django_celery_beat_crontabschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_intervalschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_intervalschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_intervalschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `every` int NOT NULL,
  `period` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_intervalschedule`
--

LOCK TABLES `django_celery_beat_intervalschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictask`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_periodictask` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `args` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `kwargs` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exchange` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `routing_key` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires` datetime(6) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_run_at` datetime(6) DEFAULT NULL,
  `total_run_count` int unsigned NOT NULL,
  `date_changed` datetime(6) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `crontab_id` int DEFAULT NULL,
  `interval_id` int DEFAULT NULL,
  `solar_id` int DEFAULT NULL,
  `one_off` tinyint(1) NOT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `priority` int unsigned DEFAULT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT (_utf8mb4'{}'),
  `clocked_id` int DEFAULT NULL,
  `expire_seconds` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` (`crontab_id`),
  KEY `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` (`interval_id`),
  KEY `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` (`solar_id`),
  KEY `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` (`clocked_id`),
  CONSTRAINT `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` FOREIGN KEY (`clocked_id`) REFERENCES `django_celery_beat_clockedschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` FOREIGN KEY (`crontab_id`) REFERENCES `django_celery_beat_crontabschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` FOREIGN KEY (`interval_id`) REFERENCES `django_celery_beat_intervalschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` FOREIGN KEY (`solar_id`) REFERENCES `django_celery_beat_solarschedule` (`id`),
  CONSTRAINT `django_celery_beat_periodictask_chk_1` CHECK ((`total_run_count` >= 0)),
  CONSTRAINT `django_celery_beat_periodictask_chk_2` CHECK ((`priority` >= 0)),
  CONSTRAINT `django_celery_beat_periodictask_chk_3` CHECK ((`expire_seconds` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictask`
--

LOCK TABLES `django_celery_beat_periodictask` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictasks`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_periodictasks` (
  `ident` smallint NOT NULL,
  `last_update` datetime(6) NOT NULL,
  PRIMARY KEY (`ident`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictasks`
--

LOCK TABLES `django_celery_beat_periodictasks` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_solarschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_solarschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_solarschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq` (`event`,`latitude`,`longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_solarschedule`
--

LOCK TABLES `django_celery_beat_solarschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(35,'analytics','crawljob'),(33,'analytics','dashcardcache'),(34,'analytics','rawcrawl'),(3,'auth','group'),(2,'auth','permission'),(26,'community','comment'),(27,'community','feedback'),(28,'community','post'),(29,'community','reaction'),(30,'community','report'),(31,'community','topic'),(32,'community','topicfollow'),(22,'content','contentreview'),(23,'content','mediaasset'),(24,'content','strategy'),(25,'content','strategycollection'),(4,'contenttypes','contenttype'),(11,'django_celery_beat','clockedschedule'),(6,'django_celery_beat','crontabschedule'),(7,'django_celery_beat','intervalschedule'),(8,'django_celery_beat','periodictask'),(9,'django_celery_beat','periodictasks'),(10,'django_celery_beat','solarschedule'),(17,'games','collection'),(16,'games','game'),(40,'games','gamescreenshot'),(14,'games','publisher'),(15,'games','tag'),(18,'recommendations','algoconfig'),(19,'recommendations','gamemetricsdaily'),(20,'recommendations','recommendation'),(21,'recommendations','userinterest'),(5,'sessions','session'),(36,'system','backupjob'),(37,'system','incentive'),(38,'system','sysconfig'),(39,'system','syslog'),(12,'users','user'),(13,'users','useroperation');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-11-06 07:33:55.571389'),(2,'contenttypes','0002_remove_content_type_name','2025-11-06 07:37:14.158903'),(3,'auth','0001_initial','2025-11-06 07:37:14.197597'),(4,'auth','0002_alter_permission_name_max_length','2025-11-06 07:37:14.205492'),(5,'auth','0003_alter_user_email_max_length','2025-11-06 07:37:14.207343'),(6,'auth','0004_alter_user_username_opts','2025-11-06 07:37:14.209143'),(7,'auth','0005_alter_user_last_login_null','2025-11-06 07:37:14.211548'),(8,'auth','0006_require_contenttypes_0002','2025-11-06 07:37:14.212356'),(9,'auth','0007_alter_validators_add_error_messages','2025-11-06 07:37:14.214140'),(10,'auth','0008_alter_user_username_max_length','2025-11-06 07:37:14.215798'),(11,'auth','0009_alter_user_last_name_max_length','2025-11-06 07:37:14.217394'),(12,'auth','0010_alter_group_name_max_length','2025-11-06 07:37:14.220574'),(13,'auth','0011_update_proxy_permissions','2025-11-06 07:37:14.222367'),(14,'auth','0012_alter_user_first_name_max_length','2025-11-06 07:37:14.223923'),(15,'users','0001_initial','2025-11-06 07:37:14.321461'),(16,'admin','0001_initial','2025-11-06 07:51:29.276377'),(17,'admin','0002_logentry_remove_auto_add','2025-11-06 07:51:29.284879'),(18,'admin','0003_logentry_add_action_flag_choices','2025-11-06 07:51:29.291884'),(19,'analytics','0001_initial','2025-11-06 07:51:29.370356'),(20,'games','0001_initial','2025-11-06 07:51:29.491879'),(21,'games','0002_initial','2025-11-06 07:51:29.594380'),(22,'content','0001_initial','2025-11-06 07:51:29.632597'),(23,'content','0002_initial','2025-11-06 07:51:29.891300'),(24,'community','0001_initial','2025-11-06 07:51:29.955946'),(25,'community','0002_initial','2025-11-06 07:51:30.836449'),(26,'django_celery_beat','0001_initial','2025-11-06 07:51:30.873932'),(27,'django_celery_beat','0002_auto_20161118_0346','2025-11-06 07:51:30.892038'),(28,'django_celery_beat','0003_auto_20161209_0049','2025-11-06 07:51:30.899127'),(29,'django_celery_beat','0004_auto_20170221_0000','2025-11-06 07:51:30.901346'),(30,'django_celery_beat','0005_add_solarschedule_events_choices','2025-11-06 07:51:30.903437'),(31,'django_celery_beat','0006_auto_20180322_0932','2025-11-06 07:51:30.930112'),(32,'django_celery_beat','0007_auto_20180521_0826','2025-11-06 07:51:30.950230'),(33,'django_celery_beat','0008_auto_20180914_1922','2025-11-06 07:51:30.961668'),(34,'django_celery_beat','0006_auto_20180210_1226','2025-11-06 07:51:30.967956'),(35,'django_celery_beat','0006_periodictask_priority','2025-11-06 07:51:30.982407'),(36,'django_celery_beat','0009_periodictask_headers','2025-11-06 07:51:30.996417'),(37,'django_celery_beat','0010_auto_20190429_0326','2025-11-06 07:51:31.052208'),(38,'django_celery_beat','0011_auto_20190508_0153','2025-11-06 07:51:31.074769'),(39,'django_celery_beat','0012_periodictask_expire_seconds','2025-11-06 07:51:31.093802'),(40,'django_celery_beat','0013_auto_20200609_0727','2025-11-06 07:51:31.097570'),(41,'django_celery_beat','0014_remove_clockedschedule_enabled','2025-11-06 07:51:31.105696'),(42,'django_celery_beat','0015_edit_solarschedule_events_choices','2025-11-06 07:51:31.107645'),(43,'django_celery_beat','0016_alter_crontabschedule_timezone','2025-11-06 07:51:31.111343'),(44,'django_celery_beat','0017_alter_crontabschedule_month_of_year','2025-11-06 07:51:31.113945'),(45,'django_celery_beat','0018_improve_crontab_helptext','2025-11-06 07:51:31.116601'),(46,'recommendations','0001_initial','2025-11-06 07:51:31.168645'),(47,'recommendations','0002_initial','2025-11-06 07:51:31.437679'),(48,'sessions','0001_initial','2025-11-06 07:51:31.445845'),(49,'system','0001_initial','2025-11-06 07:51:31.481188'),(50,'system','0002_initial','2025-11-06 07:51:31.733243'),(51,'games','0003_gamescreenshot','2025-11-07 08:47:19.775721');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('k1lbngsmbtnkusue0nwz9uegvnbhll5i','.eJxVjDsOwjAQBe_iGlnO2o4dSvqcIdr1bnAA2VI-FeLuJFIKaN_MvLcacFvzsC0yDxOrq2rU5XcjTE8pB-AHlnvVqZZ1nkgfij7povvK8rqd7t9BxiXvNaEzLbcWxAOASWDF-YjGcheQQjTROM9JdoQBhEeynU8NI4yeyIL6fAHQjzfe:1vGuxX:j0rk6xhX6J-i4872yNs992r3bK4xZwyCVw2cgzoZoo8','2025-11-20 08:03:07.394714');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedbacks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feedbacks_created_at_032bf223` (`created_at`),
  KEY `feedbacks_user_id_be6417c2_fk_users_id` (`user_id`),
  CONSTRAINT `feedbacks_user_id_be6417c2_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedbacks`
--

LOCK TABLES `feedbacks` WRITE;
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_metrics_daily`
--

DROP TABLE IF EXISTS `game_metrics_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_metrics_daily` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `downloads` int NOT NULL,
  `follows` int NOT NULL,
  `reviews` int NOT NULL,
  `posts` int NOT NULL,
  `likes` int NOT NULL,
  `comments` int NOT NULL,
  `heat_static` double NOT NULL,
  `heat_dynamic` double NOT NULL,
  `heat_total` double NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `game_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_metrics_daily_game_id_date_dda9ece7_uniq` (`game_id`,`date`),
  KEY `game_metrics_daily_date_6ceac056` (`date`),
  KEY `game_metrics_daily_heat_static_650a1227` (`heat_static`),
  KEY `game_metrics_daily_heat_dynamic_bb68b92a` (`heat_dynamic`),
  KEY `game_metrics_daily_heat_total_24983278` (`heat_total`),
  KEY `game_metric_game_id_c2d51f_idx` (`game_id`,`date` DESC),
  KEY `game_metric_date_8773fe_idx` (`date`,`heat_total` DESC),
  KEY `game_metric_heat_to_484f2f_idx` (`heat_total` DESC),
  CONSTRAINT `game_metrics_daily_game_id_359b0617_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_metrics_daily`
--

LOCK TABLES `game_metrics_daily` WRITE;
/*!40000 ALTER TABLE `game_metrics_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_metrics_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_screenshots`
--

DROP TABLE IF EXISTS `game_screenshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_screenshots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `game_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `game_screen_game_id_5e8f2c_idx` (`game_id`,`order`),
  CONSTRAINT `game_screenshots_game_id_e15a365a_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_screenshots`
--

LOCK TABLES `game_screenshots` WRITE;
/*!40000 ALTER TABLE `game_screenshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_screenshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `games` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` double NOT NULL,
  `download_count` int NOT NULL,
  `follow_count` int NOT NULL,
  `review_count` int NOT NULL,
  `release_date` date DEFAULT NULL,
  `online_time` date DEFAULT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heat_static` double NOT NULL,
  `heat_dynamic` double NOT NULL,
  `heat_total` double NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `publisher_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `games_name_f04f79a7` (`name`),
  KEY `games_category_9eb68860` (`category`),
  KEY `games_rating_759c14d5` (`rating`),
  KEY `games_download_count_292e2a1c` (`download_count`),
  KEY `games_follow_count_b5a20183` (`follow_count`),
  KEY `games_review_count_ead4b1f6` (`review_count`),
  KEY `games_release_date_89c76e73` (`release_date`),
  KEY `games_heat_static_fc176ae0` (`heat_static`),
  KEY `games_heat_dynamic_aa4659cc` (`heat_dynamic`),
  KEY `games_heat_total_01ba1807` (`heat_total`),
  KEY `games_categor_3abc27_idx` (`category`),
  KEY `games_rating_22b28e_idx` (`rating` DESC),
  KEY `games_downloa_86f943_idx` (`download_count` DESC),
  KEY `games_heat_to_6b5426_idx` (`heat_total` DESC),
  KEY `games_publish_6d05c5_idx` (`publisher_id`),
  KEY `games_release_6edf26_idx` (`release_date` DESC),
  CONSTRAINT `games_publisher_id_c3b7bd68_fk_publishers_id` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `games`
--

LOCK TABLES `games` WRITE;
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
INSERT INTO `games` VALUES (1,'王者荣耀','MOBA',9.2,50000000,8500001,2500000,'2015-11-26',NULL,'3.95.1.8','5V5英雄公平对战手游,腾讯最受欢迎的MOBA类手游。拥有海量英雄,公平竞技,实时跨区匹配,带给玩家最畅快的竞技体验。','games/covers/half.jpg',95.5,92.3,94.2,'2025-11-07 02:23:49.928287','2025-11-07 02:54:22.846477',1),(2,'和平精英','射击',8.9,45000000,7200000,1800000,'2019-05-08',NULL,'1.20.10','腾讯光子工作室群自研打造的反恐军事竞赛体验手游,虚幻引擎4研发,次世代完美画质,极致视听感受。','games/covers/half.jpg',92,88.5,90.6,'2025-11-07 02:23:49.941486','2025-11-07 02:54:22.850922',1),(3,'原神','角色扮演',9.5,38000000,9500000,3200000,'2020-09-28',NULL,'4.2.0','开放世界冒险游戏,在七种元素交汇的大陆提瓦特,你将扮演神秘角色「旅行者」,在自由的旅行中邂逅性格各异、能力独特的同伴们。','games/covers/half.jpg',98,96.5,97.4,'2025-11-07 02:23:49.951828','2025-11-07 02:54:22.854345',3),(4,'崩坏:星穹铁道','角色扮演',9.1,25000000,6800000,1500000,'2023-04-26',NULL,'1.5.0','米哈游全新银河冒险策略游戏,搭乘星穹列车,跟随「开拓」的轨迹前行,一同领略银河中瑰丽奇妙的风景。','games/covers/half.jpg',89.5,91.2,90.2,'2025-11-07 02:23:49.954155','2025-11-07 02:54:22.861146',3),(5,'梦幻西游','角色扮演',8.7,32000000,5500000,1200000,'2015-03-30',NULL,'1.358.0','网易西游题材扛鼎之作,国民级回合制手游。延续梦幻西游端游经典玩法,原汁原味还原端游体验。','games/covers/half.jpg',85,82.5,83.9,'2025-11-07 02:23:49.956290','2025-11-07 02:54:22.865506',2),(6,'第五人格','动作',8.5,28000000,4800000,980000,'2018-04-02',NULL,'1.0.1820000','网易首款非对称性对抗竞技手游,荒诞哥特画风,悬疑烧脑剧情,刺激的1V4对抗玩法。','games/covers/half.jpg',82.5,80,81.5,'2025-11-07 02:23:49.958332','2025-11-07 02:54:22.871422',2),(7,'剑与远征','策略',8.8,22000000,4200000,850000,'2019-08-21',NULL,'1.125.01','轻松放置,策略为王。莉莉丝游戏打造的放置类卡牌手游,精美的美式画风,丰富的英雄养成。','games/covers/half.jpg',80,78.5,79.4,'2025-11-07 02:23:49.961599','2025-11-07 02:54:22.876016',4),(8,'万国觉醒','策略',8.6,20000000,3800000,720000,'2018-09-23',NULL,'1.0.70.28','多文明战争策略手游,选择11个文明中的一个,发展城市,训练军队,征服世界。','games/covers/half.jpg',78.5,76,77.5,'2025-11-07 02:23:49.965269','2025-11-07 02:54:22.881134',4),(9,'明日方舟','策略',9,18000000,5200000,1100000,'2019-05-01',NULL,'1.9.81','策略塔防手游,在这个废土世界中,你将作为罗德岛的领导者,带领干员们对抗感染者危机。','games/covers/half.jpg',87,85.5,86.4,'2025-11-07 02:23:49.968054','2025-11-07 02:54:22.888238',5),(10,'碧蓝航线','角色扮演',8.7,16000000,4500000,890000,'2017-09-14',NULL,'7.0.0','二次元海战题材即时海战手游,萌系舰娘养成,即时海战玩法,为你带来全新的游戏体验。','games/covers/half.jpg',81.5,79,80.4,'2025-11-07 02:23:49.971057','2025-11-07 02:54:22.900865',5),(11,'英雄联盟手游','MOBA',8.8,35000000,6500000,1600000,'2021-10-08',NULL,'5.0.0.7359','英雄联盟正版MOBA手游,经典还原端游体验,公平竞技,策略对战,带给你最纯粹的MOBA体验。','games/covers/half.jpg',88,86,87.2,'2025-11-07 02:23:49.973674','2025-11-07 02:54:22.910614',1),(12,'金铲铲之战','策略',8.4,24000000,3900000,680000,'2021-08-26',NULL,'7.18.1','英雄联盟云顶之弈正版授权自走棋手游,8人公平竞技,策略组合,轻松休闲的自走棋玩法。','games/covers/half.jpg',79,77.5,78.4,'2025-11-07 02:23:49.975573','2025-11-07 02:54:22.920166',1),(13,'阴阳师','角色扮演',8.6,26000000,4600000,950000,'2016-09-02',NULL,'1.7.68','网易和风唯美卡牌手游,3D唯美画面,日本顶级声优阵容,带你进入神秘的平安时代。','games/covers/half.jpg',83,81,82.2,'2025-11-07 02:23:49.977668','2025-11-07 02:54:22.932427',2),(14,'蛋仔派对','休闲',8.9,42000000,7800000,1900000,'2022-05-27',NULL,'1.0.72','网易潮玩竞技手游,Q萌蛋仔形象,创意关卡设计,支持自定义地图,和朋友一起快乐闯关。','games/covers/half.jpg',91,93.5,92,'2025-11-07 02:23:49.980364','2025-11-07 02:54:22.935542',2),(15,'光·遇','冒险',9.3,19000000,6200000,1400000,'2020-07-09',NULL,'0.9.5','网易代理的社交冒险游戏,唯美治愈的画风,温暖的社交体验,在云端探索,与人相遇相知。','games/covers/half.jpg',89,87.5,88.4,'2025-11-07 02:23:49.984105','2025-11-07 02:54:22.941018',2),(16,'部落冲突','策略',8.7,30000000,5100000,1050000,'2012-08-02',NULL,'16.0.8','全球最受欢迎的策略游戏,建造村庄,训练军队,与全球玩家战斗,加入部落,参与部落战争。','games/covers/half.jpg',84.5,82,83.5,'2025-11-07 02:23:49.986413','2025-11-07 02:54:22.944198',1),(17,'我的世界','沙盒',9.1,36000000,7500000,1750000,'2017-09-15',NULL,'1.20.50.21','自由沙盒建造游戏,在这个方块世界中,你可以建造任何你想象的东西,探索无限的可能。','games/covers/half.jpg',90,88.5,89.4,'2025-11-07 02:23:49.988657','2025-11-07 02:54:22.948471',2),(18,'元气骑士','动作',9,15000000,4800000,1100000,'2017-02-17',NULL,'5.5.0','像素风地牢射击游戏,简单的操作,丰富的武器系统,随机生成的地牢,带来无限的游戏乐趣。','games/covers/half.jpg',86.5,85,85.9,'2025-11-07 02:23:49.991519','2025-11-07 02:54:22.955035',5),(19,'三国杀','卡牌',8.3,21000000,3500000,650000,'2012-01-01',NULL,'3.9.8','经典桌游改编手游,三国题材卡牌对战,策略性强,支持多人在线对战,经典身份局玩法。','games/covers/half.jpg',76,74.5,75.4,'2025-11-07 02:23:49.994883','2025-11-07 02:54:22.963964',1),(20,'火影忍者','格斗',8.8,27000000,5300000,1150000,'2016-05-19',NULL,'3.78.2.2','火影忍者正版授权手游,高度还原动漫剧情,流畅的格斗体验,丰富的忍者收集养成。','games/covers/half.jpg',84,82.5,83.4,'2025-11-07 02:23:49.997054','2025-11-07 02:54:22.967379',1);
/*!40000 ALTER TABLE `games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `games_tags`
--

DROP TABLE IF EXISTS `games_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `games_tags` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `game_id` bigint NOT NULL,
  `tag_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `games_tags_game_id_tag_id_2a289516_uniq` (`game_id`,`tag_id`),
  KEY `games_tags_tag_id_719a7ff0_fk_tags_id` (`tag_id`),
  CONSTRAINT `games_tags_game_id_a3f1a80a_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`),
  CONSTRAINT `games_tags_tag_id_719a7ff0_fk_tags_id` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `games_tags`
--

LOCK TABLES `games_tags` WRITE;
/*!40000 ALTER TABLE `games_tags` DISABLE KEYS */;
INSERT INTO `games_tags` VALUES (1,1,1),(2,1,3),(3,1,13),(4,2,1),(5,2,3),(7,2,7),(6,2,13),(8,3,6),(9,3,8),(10,3,11),(11,3,12),(12,3,13),(13,4,6),(14,4,8),(15,4,12),(16,4,13),(17,4,15),(19,5,1),(18,5,8),(20,5,15),(21,6,1),(22,6,3),(23,6,6),(26,7,4),(27,7,5),(24,7,8),(25,7,9),(28,8,1),(30,8,5),(29,8,13),(33,9,5),(31,9,8),(32,9,12),(37,10,7),(34,10,8),(35,10,9),(36,10,12),(38,11,1),(39,11,3),(40,11,13),(41,12,1),(42,12,4),(43,12,5),(44,13,8),(45,13,9),(46,13,12),(47,13,15),(48,14,1),(49,14,3),(50,14,4),(51,14,13),(52,15,1),(53,15,4),(55,15,6),(54,15,13),(56,16,1),(58,16,5),(57,16,10),(59,17,1),(60,17,6),(61,17,14),(62,18,2),(63,18,6),(65,18,7),(64,18,14),(68,19,1),(67,19,5),(66,19,9),(69,20,3),(70,20,12);
/*!40000 ALTER TABLE `games_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incentives`
--

DROP TABLE IF EXISTS `incentives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incentives` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `period` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exposure` int NOT NULL,
  `likes` int NOT NULL,
  `comments` int NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_note` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `reviewed_at` datetime(6) DEFAULT NULL,
  `granted_at` datetime(6) DEFAULT NULL,
  `author_id` bigint NOT NULL,
  `reviewer_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incentives_status_48457618` (`status`),
  KEY `incentives_created_at_b5808de0` (`created_at`),
  KEY `incentives_reviewer_id_80d8ce0a_fk_users_id` (`reviewer_id`),
  KEY `incentives_author__e9147d_idx` (`author_id`,`created_at` DESC),
  KEY `incentives_status_5164ec_idx` (`status`,`created_at` DESC),
  KEY `incentives_period_32246d_idx` (`period`),
  CONSTRAINT `incentives_author_id_83a233ed_fk_users_id` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `incentives_reviewer_id_80d8ce0a_fk_users_id` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incentives`
--

LOCK TABLES `incentives` WRITE;
/*!40000 ALTER TABLE `incentives` DISABLE KEYS */;
/*!40000 ALTER TABLE `incentives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_assets`
--

DROP TABLE IF EXISTS `media_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_assets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta` json NOT NULL,
  `order` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `strategy_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `media_asset_strateg_2e1708_idx` (`strategy_id`,`order`),
  CONSTRAINT `media_assets_strategy_id_61ab7ecd_fk_strategies_id` FOREIGN KEY (`strategy_id`) REFERENCES `strategies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_assets`
--

LOCK TABLES `media_assets` WRITE;
/*!40000 ALTER TABLE `media_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `like_count` int NOT NULL,
  `comment_count` int NOT NULL,
  `share_count` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `author_id` bigint NOT NULL,
  `game_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_is_deleted_bf13a5c1` (`is_deleted`),
  KEY `posts_created_at_ec043a9f` (`created_at`),
  KEY `posts_author__f2f966_idx` (`author_id`,`created_at` DESC),
  KEY `posts_game_id_91d4af_idx` (`game_id`,`created_at` DESC),
  KEY `posts_is_dele_3cc8cf_idx` (`is_deleted`,`created_at` DESC),
  KEY `posts_like_co_2a104b_idx` (`like_count` DESC),
  CONSTRAINT `posts_author_id_099b8aca_fk_users_id` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `posts_game_id_0fa70f00_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_mentions`
--

DROP TABLE IF EXISTS `posts_mentions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts_mentions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_mentions_post_id_user_id_4051d7e7_uniq` (`post_id`,`user_id`),
  KEY `posts_mentions_user_id_435b8bda_fk_users_id` (`user_id`),
  CONSTRAINT `posts_mentions_post_id_a932d5e4_fk_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `posts_mentions_user_id_435b8bda_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_mentions`
--

LOCK TABLES `posts_mentions` WRITE;
/*!40000 ALTER TABLE `posts_mentions` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_mentions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_topics`
--

DROP TABLE IF EXISTS `posts_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts_topics` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `post_id` bigint NOT NULL,
  `topic_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_topics_post_id_topic_id_93050954_uniq` (`post_id`,`topic_id`),
  KEY `posts_topics_topic_id_d9ce9b6f_fk_topics_id` (`topic_id`),
  CONSTRAINT `posts_topics_post_id_fe72425d_fk_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `posts_topics_topic_id_d9ce9b6f_fk_topics_id` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_topics`
--

LOCK TABLES `posts_topics` WRITE;
/*!40000 ALTER TABLE `posts_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publishers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_info` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishers`
--

LOCK TABLES `publishers` WRITE;
/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` VALUES (1,'腾讯游戏','contact@tencent.com','','中国领先的游戏发行商,致力于为玩家提供优质的游戏体验','https://game.qq.com','2025-11-07 02:23:49.802027','2025-11-07 02:23:49.802063'),(2,'网易游戏','contact@netease.com','','网易旗下游戏发行平台,专注于精品游戏研发与发行','https://game.163.com','2025-11-07 02:23:49.811005','2025-11-07 02:23:49.811029'),(3,'米哈游','contact@mihoyo.com','','技术宅拯救世界,专注于原创IP游戏开发','https://www.mihoyo.com','2025-11-07 02:23:49.812991','2025-11-07 02:23:49.813009'),(4,'莉莉丝游戏','contact@lilith.com','','专注于创新玩法的游戏公司','https://www.lilith.com','2025-11-07 02:23:49.816158','2025-11-07 02:23:49.816177'),(5,'心动网络','contact@xd.com','','为玩家带来快乐的游戏公司','https://www.xd.com','2025-11-07 02:23:49.819156','2025-11-07 02:23:49.819178');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raw_crawls`
--

DROP TABLE IF EXISTS `raw_crawls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `raw_crawls` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` json NOT NULL,
  `hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`),
  KEY `raw_crawls_source_ee1e5739` (`source`),
  KEY `raw_crawls_created_at_66b1f7bd` (`created_at`),
  KEY `raw_crawls_source_f81ceb_idx` (`source`,`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raw_crawls`
--

LOCK TABLES `raw_crawls` WRITE;
/*!40000 ALTER TABLE `raw_crawls` DISABLE KEYS */;
/*!40000 ALTER TABLE `raw_crawls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reactions`
--

DROP TABLE IF EXISTS `reactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reactions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `content_type_id` int NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reactions_user_id_content_type_id_object_id_type_41d6dd1f_uniq` (`user_id`,`content_type_id`,`object_id`,`type`),
  KEY `reactions_object_id_4776cc25` (`object_id`),
  KEY `reactions_content_714634_idx` (`content_type_id`,`object_id`),
  KEY `reactions_user_id_5ab237_idx` (`user_id`,`created_at` DESC),
  CONSTRAINT `reactions_content_type_id_b5675cb2_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `reactions_user_id_cc1df63a_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reactions_chk_1` CHECK ((`object_id` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reactions`
--

LOCK TABLES `reactions` WRITE;
/*!40000 ALTER TABLE `reactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `reactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendations`
--

DROP TABLE IF EXISTS `recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `reason` json NOT NULL,
  `score` double NOT NULL,
  `generated_at` datetime(6) NOT NULL,
  `game_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recommendations_score_629bbcad` (`score`),
  KEY `recommendations_generated_at_914f0d12` (`generated_at`),
  KEY `recommendat_user_id_8236a6_idx` (`user_id`,`score` DESC),
  KEY `recommendat_game_id_50465e_idx` (`game_id`,`generated_at` DESC),
  KEY `recommendat_generat_387346_idx` (`generated_at` DESC),
  CONSTRAINT `recommendations_game_id_0548a1ba_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`),
  CONSTRAINT `recommendations_user_id_2629d798_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendations`
--

LOCK TABLES `recommendations` WRITE;
/*!40000 ALTER TABLE `recommendations` DISABLE KEYS */;
INSERT INTO `recommendations` VALUES (13,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"3D\", \"多人在线\", \"竞技\"]}',1.0000000000000002,'2025-11-07 14:37:07.459616',11,2),(14,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"3D\", \"多人在线\", \"竞技\"]}',0.8660254037844387,'2025-11-07 14:37:07.459659',14,2),(15,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"3D\", \"多人在线\", \"竞技\"]}',0.8660254037844387,'2025-11-07 14:37:07.459682',2,2),(16,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"多人在线\", \"竞技\"]}',0.6666666666666667,'2025-11-07 14:37:07.459703',6,2),(17,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"3D\", \"多人在线\"]}',0.6666666666666667,'2025-11-07 14:37:07.459722',8,2),(18,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"3D\", \"多人在线\"]}',0.5773502691896258,'2025-11-07 14:37:07.459740',15,2),(19,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"竞技\"]}',0.40824829046386296,'2025-11-07 14:37:07.459759',20,2),(20,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"多人在线\"]}',0.33333333333333337,'2025-11-07 14:37:07.459776',17,2),(21,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"多人在线\"]}',0.33333333333333337,'2025-11-07 14:37:07.459794',5,2),(22,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"多人在线\"]}',0.33333333333333337,'2025-11-07 14:37:07.459812',16,2),(23,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"多人在线\"]}',0.33333333333333337,'2025-11-07 14:37:07.459830',12,2),(24,'{\"type\": \"tag_similarity\", \"matched_tags\": [\"多人在线\"]}',0.33333333333333337,'2025-11-07 14:37:07.459847',19,2);
/*!40000 ALTER TABLE `recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `object_id` int unsigned NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `handle_result` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `handled_at` datetime(6) DEFAULT NULL,
  `content_type_id` int NOT NULL,
  `handler_id` bigint DEFAULT NULL,
  `reporter_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_object_id_7eb2f08c` (`object_id`),
  KEY `reports_status_b3805644` (`status`),
  KEY `reports_created_at_59903879` (`created_at`),
  KEY `reports_handler_id_073b8cfa_fk_users_id` (`handler_id`),
  KEY `reports_status_d7deb7_idx` (`status`,`created_at` DESC),
  KEY `reports_reporte_25ecfc_idx` (`reporter_id`,`created_at` DESC),
  KEY `reports_content_0cd725_idx` (`content_type_id`,`object_id`),
  CONSTRAINT `reports_content_type_id_2e7aa4e2_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `reports_handler_id_073b8cfa_fk_users_id` FOREIGN KEY (`handler_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reports_reporter_id_ef570044_fk_users_id` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reports_chk_1` CHECK ((`object_id` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `strategies`
--

DROP TABLE IF EXISTS `strategies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `strategies` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_count` int NOT NULL,
  `like_count` int NOT NULL,
  `collect_count` int NOT NULL,
  `publish_date` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `author_id` bigint NOT NULL,
  `game_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `strategies_title_19e32010` (`title`),
  KEY `strategies_status_40d22b1b` (`status`),
  KEY `strategies_publish_date_80ca5775` (`publish_date`),
  KEY `strategies_game_id_205630_idx` (`game_id`,`publish_date` DESC),
  KEY `strategies_author__f83dcd_idx` (`author_id`,`created_at` DESC),
  KEY `strategies_status_de6fd0_idx` (`status`),
  KEY `strategies_like_co_b0a6fe_idx` (`like_count` DESC),
  CONSTRAINT `strategies_author_id_73eb4ed9_fk_users_id` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `strategies_game_id_295d0015_fk_games_id` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `strategies`
--

LOCK TABLES `strategies` WRITE;
/*!40000 ALTER TABLE `strategies` DISABLE KEYS */;
/*!40000 ALTER TABLE `strategies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `strategy_collections`
--

DROP TABLE IF EXISTS `strategy_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `strategy_collections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `strategy_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `strategy_collections_user_id_strategy_id_b96db7c4_uniq` (`user_id`,`strategy_id`),
  KEY `strategy_collections_strategy_id_c530fb9c_fk_strategies_id` (`strategy_id`),
  KEY `strategy_co_user_id_6cf6a9_idx` (`user_id`,`created_at` DESC),
  CONSTRAINT `strategy_collections_strategy_id_c530fb9c_fk_strategies_id` FOREIGN KEY (`strategy_id`) REFERENCES `strategies` (`id`),
  CONSTRAINT `strategy_collections_user_id_6ff59e76_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `strategy_collections`
--

LOCK TABLES `strategy_collections` WRITE;
/*!40000 ALTER TABLE `strategy_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `strategy_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config`
--

LOCK TABLES `sys_config` WRITE;
/*!40000 ALTER TABLE `sys_config` DISABLE KEYS */;
INSERT INTO `sys_config` VALUES (1,'site.name','游戏推荐','网站名称',1,'2025-11-07 16:32:11.864142'),(2,'site.description','专业的游戏推荐和攻略分享平台','网站描述',1,'2025-11-07 16:28:56.254983'),(3,'site.keywords','游戏,推荐,攻略,社区','网站关键词',1,'2025-11-07 16:28:56.260736'),(4,'site.logo','/static/logo.png','网站Logo地址',1,'2025-11-07 16:28:56.263533'),(5,'user.registration.enabled','true','是否允许用户注册',1,'2025-11-07 16:28:56.268367'),(6,'user.password.min_length','8','密码最小长度',0,'2025-11-07 16:28:56.277964'),(7,'user.verification.email','false','是否需要邮箱验证',0,'2025-11-07 16:28:56.287622'),(8,'content.review.auto_approve','false','是否自动通过内容审核',0,'2025-11-07 16:28:56.299473'),(9,'content.review.keywords','赌博,暴力,色情','敏感词列表（逗号分隔）',0,'2025-11-07 16:28:56.317110'),(10,'recommend.algorithm','collaborative','推荐算法：collaborative/content_based/hybrid',0,'2025-11-07 16:28:56.321034'),(11,'recommend.cache.ttl','3600','推荐结果缓存时间（秒）',0,'2025-11-07 16:28:56.323347'),(12,'system.maintenance.mode','false','系统维护模式',1,'2025-11-07 16:28:56.339936'),(13,'system.maintenance.message','系统正在维护中，请稍后访问','维护模式提示信息',1,'2025-11-07 16:28:56.341930'),(14,'system.log.retention_days','30','日志保留天数',0,'2025-11-07 16:28:56.346572'),(15,'system.backup.auto_enabled','true','是否启用自动备份',0,'2025-11-07 16:28:56.348547'),(16,'system.backup.schedule','0 2 * * *','自动备份计划（Cron表达式）',0,'2025-11-07 16:28:56.360796'),(17,'system.backup.retention_count','7','备份文件保留数量',0,'2025-11-07 16:28:56.367400'),(18,'upload.max_size','10485760','最大上传文件大小（字节），默认10MB',0,'2025-11-07 16:28:56.369361'),(19,'upload.allowed_types','jpg,jpeg,png,gif,mp4','允许上传的文件类型',0,'2025-11-07 16:28:56.395010');
/*!40000 ALTER TABLE `sys_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_logs`
--

DROP TABLE IF EXISTS `sys_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `level` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` json DEFAULT NULL,
  `ip_address` char(39) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sys_logs_level_60f0b98b` (`level`),
  KEY `sys_logs_module_fb42bb44` (`module`),
  KEY `sys_logs_created_at_5536f7fe` (`created_at`),
  KEY `sys_logs_level_d66798_idx` (`level`,`created_at` DESC),
  KEY `sys_logs_module_54c6cd_idx` (`module`,`created_at` DESC),
  KEY `sys_logs_user_id_83c89b_idx` (`user_id`,`created_at` DESC),
  CONSTRAINT `sys_logs_user_id_d23cbae6_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_logs`
--

LOCK TABLES `sys_logs` WRITE;
/*!40000 ALTER TABLE `sys_logs` DISABLE KEYS */;
INSERT INTO `sys_logs` VALUES (1,'WARNING','content','清理过期日志','{\"path\": \"/api/v1/content/\", \"test\": true, \"action\": \"清理过期日志\", \"method\": \"GET\", \"timestamp\": \"2025-11-05T12:59:02.111350+00:00\", \"status_code\": 204}','192.168.31.229','2025-11-05 12:59:02.111350',NULL),(2,'WARNING','user','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-11-01T13:42:02.118105+00:00\"}','192.168.236.244','2025-11-01 13:42:02.118105',1),(3,'WARNING','api','更新配置','{\"test\": true, \"action\": \"更新配置\", \"timestamp\": \"2025-11-02T09:54:02.119851+00:00\"}','192.168.136.198','2025-11-02 09:54:02.119851',1),(4,'DEBUG','auth','内容审核拒绝','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"内容审核拒绝\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-04T20:32:02.121742+00:00\", \"status_code\": 201}','192.168.149.186','2025-11-04 20:32:02.121742',1),(5,'INFO','user','封禁用户','{\"test\": true, \"action\": \"封禁用户\", \"timestamp\": \"2025-11-02T03:44:02.123169+00:00\"}','192.168.46.251','2025-11-02 03:44:02.123169',1),(6,'ERROR','content','内容审核拒绝','{\"test\": true, \"action\": \"内容审核拒绝\", \"timestamp\": \"2025-11-03T11:18:02.124415+00:00\"}','192.168.4.214','2025-11-03 11:18:02.124415',1),(7,'DEBUG','system','内容审核通过','{\"test\": true, \"action\": \"内容审核通过\", \"timestamp\": \"2025-11-05T19:20:02.125638+00:00\"}','192.168.192.91','2025-11-05 19:20:02.125638',1),(8,'WARNING','user','密码重置请求','{\"test\": true, \"action\": \"密码重置请求\", \"timestamp\": \"2025-11-01T18:48:02.126938+00:00\"}','192.168.215.135','2025-11-01 18:48:02.126938',NULL),(9,'INFO','auth','系统配置更新','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"系统配置更新\", \"method\": \"GET\", \"timestamp\": \"2025-11-02T07:22:02.127927+00:00\", \"status_code\": 400}','192.168.57.160','2025-11-02 07:22:02.127927',1),(10,'DEBUG','system','用户权限变更','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"用户权限变更\", \"method\": \"GET\", \"timestamp\": \"2025-11-05T14:56:02.129077+00:00\", \"status_code\": 204}','192.168.131.224','2025-11-05 14:56:02.129077',1),(11,'INFO','api','解封用户','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"解封用户\", \"method\": \"PUT\", \"timestamp\": \"2025-11-07T11:27:02.130185+00:00\", \"status_code\": 400}','192.168.169.159','2025-11-07 11:27:02.130185',1),(12,'DEBUG','api','数据库备份开始','{\"test\": true, \"action\": \"数据库备份开始\", \"timestamp\": \"2025-11-06T06:07:02.131495+00:00\"}','192.168.129.37','2025-11-06 06:07:02.131495',1),(13,'ERROR','system','内容审核通过','{\"test\": true, \"action\": \"内容审核通过\", \"timestamp\": \"2025-11-03T04:07:02.132825+00:00\"}','192.168.5.185','2025-11-03 04:07:02.132825',1),(14,'WARNING','content','数据库备份完成','{\"path\": \"/api/v1/content/\", \"test\": true, \"action\": \"数据库备份完成\", \"method\": \"POST\", \"timestamp\": \"2025-11-05T01:55:02.134171+00:00\", \"status_code\": 200}','192.168.76.61','2025-11-05 01:55:02.134171',1),(15,'DEBUG','system','用户注册','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"用户注册\", \"method\": \"GET\", \"timestamp\": \"2025-11-04T01:52:02.135879+00:00\", \"status_code\": 400}','192.168.15.192','2025-11-04 01:52:02.135879',1),(16,'ERROR','content','封禁用户','{\"path\": \"/api/v1/content/\", \"test\": true, \"action\": \"封禁用户\", \"method\": \"POST\", \"timestamp\": \"2025-11-01T22:19:02.136862+00:00\", \"status_code\": 400}','192.168.249.60','2025-11-01 22:19:02.136862',1),(17,'ERROR','auth','内容审核通过','{\"test\": true, \"action\": \"内容审核通过\", \"timestamp\": \"2025-11-05T05:37:02.137965+00:00\"}','192.168.111.142','2025-11-05 05:37:02.137965',1),(18,'INFO','api','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-10-31T19:48:02.139170+00:00\"}','192.168.100.112','2025-10-31 19:48:02.139170',1),(19,'CRITICAL','user','创建新内容','{\"test\": true, \"action\": \"创建新内容\", \"timestamp\": \"2025-11-06T02:34:02.140543+00:00\"}','192.168.160.155','2025-11-06 02:34:02.140543',NULL),(20,'INFO','auth','密码重置请求','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"密码重置请求\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-07T00:28:02.141422+00:00\", \"status_code\": 404}','192.168.225.118','2025-11-07 00:28:02.141422',1),(21,'ERROR','auth','内容审核拒绝','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"内容审核拒绝\", \"method\": \"POST\", \"timestamp\": \"2025-11-04T14:55:02.142334+00:00\", \"status_code\": 204}','192.168.44.179','2025-11-04 14:55:02.142334',NULL),(22,'ERROR','auth','清理过期日志','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"清理过期日志\", \"method\": \"POST\", \"timestamp\": \"2025-11-01T15:46:02.143575+00:00\", \"status_code\": 400}','192.168.195.34','2025-11-01 15:46:02.143575',1),(23,'ERROR','backup','数据库备份完成','{\"test\": true, \"action\": \"数据库备份完成\", \"timestamp\": \"2025-11-06T13:12:02.144642+00:00\"}','192.168.143.78','2025-11-06 13:12:02.144642',NULL),(24,'CRITICAL','content','用户登出','{\"test\": true, \"action\": \"用户登出\", \"timestamp\": \"2025-10-30T20:16:02.145578+00:00\"}','192.168.12.156','2025-10-30 20:16:02.145578',1),(25,'ERROR','backup','内容审核通过','{\"test\": true, \"action\": \"内容审核通过\", \"timestamp\": \"2025-10-30T23:28:02.146943+00:00\"}','192.168.249.238','2025-10-30 23:28:02.146943',1),(26,'ERROR','user','数据库备份开始','{\"test\": true, \"action\": \"数据库备份开始\", \"timestamp\": \"2025-11-05T06:26:02.148870+00:00\"}','192.168.160.191','2025-11-05 06:26:02.148870',1),(27,'ERROR','system','密码重置请求','{\"test\": true, \"action\": \"密码重置请求\", \"timestamp\": \"2025-10-31T23:48:02.149794+00:00\"}','192.168.214.242','2025-10-31 23:48:02.149794',1),(28,'ERROR','content','用户权限变更','{\"path\": \"/api/v1/content/\", \"test\": true, \"action\": \"用户权限变更\", \"method\": \"PUT\", \"timestamp\": \"2025-11-02T08:50:02.150992+00:00\", \"status_code\": 400}','192.168.200.186','2025-11-02 08:50:02.150992',1),(29,'DEBUG','user','数据库备份完成','{\"test\": true, \"action\": \"数据库备份完成\", \"timestamp\": \"2025-11-04T01:37:02.152177+00:00\"}','192.168.103.18','2025-11-04 01:37:02.152177',1),(30,'WARNING','backup','用户登出','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"用户登出\", \"method\": \"DELETE\", \"timestamp\": \"2025-10-31T16:35:02.153573+00:00\", \"status_code\": 201}','192.168.209.226','2025-10-31 16:35:02.153573',1),(31,'WARNING','backup','数据库备份完成','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"数据库备份完成\", \"method\": \"POST\", \"timestamp\": \"2025-11-07T03:20:02.154334+00:00\", \"status_code\": 500}','192.168.133.200','2025-11-07 03:20:02.154334',1),(32,'CRITICAL','backup','用户注册','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"用户注册\", \"method\": \"GET\", \"timestamp\": \"2025-11-05T19:17:02.155243+00:00\", \"status_code\": 204}','192.168.139.113','2025-11-05 19:17:02.155243',NULL),(33,'ERROR','auth','解封用户','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"解封用户\", \"method\": \"POST\", \"timestamp\": \"2025-11-04T05:18:02.156572+00:00\", \"status_code\": 201}','192.168.226.238','2025-11-04 05:18:02.156572',1),(34,'CRITICAL','content','封禁用户','{\"test\": true, \"action\": \"封禁用户\", \"timestamp\": \"2025-11-05T19:09:02.157595+00:00\"}','192.168.185.160','2025-11-05 19:09:02.157595',1),(35,'CRITICAL','backup','用户登录成功','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"用户登录成功\", \"method\": \"DELETE\", \"timestamp\": \"2025-10-31T19:06:02.158469+00:00\", \"status_code\": 500}','192.168.55.58','2025-10-31 19:06:02.158469',NULL),(36,'DEBUG','auth','系统配置更新','{\"test\": true, \"action\": \"系统配置更新\", \"timestamp\": \"2025-11-01T13:16:02.159602+00:00\"}','192.168.55.148','2025-11-01 13:16:02.159602',1),(37,'DEBUG','system','数据库备份完成','{\"test\": true, \"action\": \"数据库备份完成\", \"timestamp\": \"2025-11-04T08:20:02.161722+00:00\"}','192.168.123.144','2025-11-04 08:20:02.161722',1),(38,'INFO','content','解封用户','{\"path\": \"/api/v1/content/\", \"test\": true, \"action\": \"解封用户\", \"method\": \"POST\", \"timestamp\": \"2025-11-06T20:27:02.163111+00:00\", \"status_code\": 204}','192.168.159.165','2025-11-06 20:27:02.163111',NULL),(39,'WARNING','system','封禁用户','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"封禁用户\", \"method\": \"GET\", \"timestamp\": \"2025-11-01T03:43:02.164426+00:00\", \"status_code\": 204}','192.168.131.101','2025-11-01 03:43:02.164426',1),(40,'CRITICAL','user','更新配置','{\"path\": \"/api/v1/user/\", \"test\": true, \"action\": \"更新配置\", \"method\": \"PUT\", \"timestamp\": \"2025-11-01T12:51:02.165732+00:00\", \"status_code\": 204}','192.168.10.237','2025-11-01 12:51:02.165732',1),(41,'WARNING','user','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-11-06T06:37:02.166676+00:00\"}','192.168.96.226','2025-11-06 06:37:02.166676',1),(42,'CRITICAL','api','用户登录成功','{\"test\": true, \"action\": \"用户登录成功\", \"timestamp\": \"2025-11-05T17:15:02.168041+00:00\"}','192.168.183.137','2025-11-05 17:15:02.168041',1),(43,'CRITICAL','backup','内容审核拒绝','{\"test\": true, \"action\": \"内容审核拒绝\", \"timestamp\": \"2025-11-04T20:37:02.169228+00:00\"}','192.168.56.151','2025-11-04 20:37:02.169228',1),(44,'DEBUG','backup','更新配置','{\"test\": true, \"action\": \"更新配置\", \"timestamp\": \"2025-11-01T01:28:02.170539+00:00\"}','192.168.47.215','2025-11-01 01:28:02.170539',NULL),(45,'ERROR','backup','内容审核通过','{\"test\": true, \"action\": \"内容审核通过\", \"timestamp\": \"2025-11-04T02:54:02.171318+00:00\"}','192.168.29.23','2025-11-04 02:54:02.171318',NULL),(46,'INFO','system','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-11-01T02:34:02.172087+00:00\"}','192.168.118.226','2025-11-01 02:34:02.172087',1),(47,'WARNING','api','封禁用户','{\"test\": true, \"action\": \"封禁用户\", \"timestamp\": \"2025-11-02T13:07:02.172849+00:00\"}','192.168.59.69','2025-11-02 13:07:02.172849',1),(48,'WARNING','backup','内容审核通过','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"内容审核通过\", \"method\": \"DELETE\", \"timestamp\": \"2025-10-31T02:43:02.173581+00:00\", \"status_code\": 204}','192.168.56.48','2025-10-31 02:43:02.173581',1),(49,'DEBUG','user','清理过期日志','{\"path\": \"/api/v1/user/\", \"test\": true, \"action\": \"清理过期日志\", \"method\": \"PUT\", \"timestamp\": \"2025-11-06T13:50:02.174482+00:00\", \"status_code\": 204}','192.168.132.94','2025-11-06 13:50:02.174482',NULL),(50,'DEBUG','content','内容审核拒绝','{\"test\": true, \"action\": \"内容审核拒绝\", \"timestamp\": \"2025-11-04T21:59:02.175323+00:00\"}','192.168.48.223','2025-11-04 21:59:02.175323',1),(51,'INFO','api','用户权限变更','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"用户权限变更\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-04T14:01:02.176505+00:00\", \"status_code\": 201}','192.168.175.67','2025-11-04 14:01:02.176505',1),(52,'DEBUG','user','用户权限变更','{\"test\": true, \"action\": \"用户权限变更\", \"timestamp\": \"2025-11-01T00:34:02.177321+00:00\"}','192.168.65.128','2025-11-01 00:34:02.177321',1),(53,'INFO','system','清理过期日志','{\"test\": true, \"action\": \"清理过期日志\", \"timestamp\": \"2025-11-07T07:17:02.178249+00:00\"}','192.168.9.39','2025-11-07 07:17:02.178249',NULL),(54,'CRITICAL','backup','用户权限变更','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"用户权限变更\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-02T07:59:02.179921+00:00\", \"status_code\": 400}','192.168.180.162','2025-11-02 07:59:02.179921',1),(55,'INFO','auth','用户登出','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"用户登出\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-03T23:01:02.180930+00:00\", \"status_code\": 204}','192.168.219.139','2025-11-03 23:01:02.180930',1),(56,'INFO','auth','密码重置请求','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"密码重置请求\", \"method\": \"POST\", \"timestamp\": \"2025-11-02T06:05:02.181821+00:00\", \"status_code\": 500}','192.168.155.179','2025-11-02 06:05:02.181821',NULL),(57,'CRITICAL','system','封禁用户','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"封禁用户\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-05T14:57:02.182604+00:00\", \"status_code\": 400}','192.168.25.176','2025-11-05 14:57:02.182604',NULL),(58,'ERROR','api','清理过期日志','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"清理过期日志\", \"method\": \"POST\", \"timestamp\": \"2025-10-30T22:46:02.183380+00:00\", \"status_code\": 201}','192.168.239.80','2025-10-30 22:46:02.183380',1),(59,'INFO','user','密码重置请求','{\"test\": true, \"action\": \"密码重置请求\", \"timestamp\": \"2025-11-01T19:07:02.184304+00:00\"}','192.168.151.243','2025-11-01 19:07:02.184304',1),(60,'CRITICAL','content','封禁用户','{\"test\": true, \"action\": \"封禁用户\", \"timestamp\": \"2025-11-04T15:58:02.185644+00:00\"}','192.168.153.41','2025-11-04 15:58:02.185644',NULL),(61,'INFO','api','解封用户','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"解封用户\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-07T14:34:02.186783+00:00\", \"status_code\": 404}','192.168.82.76','2025-11-07 14:34:02.186783',1),(62,'DEBUG','user','内容审核通过','{\"test\": true, \"action\": \"内容审核通过\", \"timestamp\": \"2025-11-07T08:59:02.187768+00:00\"}','192.168.221.36','2025-11-07 08:59:02.187768',1),(63,'ERROR','user','解封用户','{\"test\": true, \"action\": \"解封用户\", \"timestamp\": \"2025-11-01T11:35:02.189360+00:00\"}','192.168.254.145','2025-11-01 11:35:02.189360',1),(64,'WARNING','system','封禁用户','{\"test\": true, \"action\": \"封禁用户\", \"timestamp\": \"2025-11-03T22:20:02.190739+00:00\"}','192.168.61.165','2025-11-03 22:20:02.190739',1),(65,'WARNING','auth','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-11-07T03:26:02.192378+00:00\"}','192.168.195.101','2025-11-07 03:26:02.192378',1),(66,'INFO','auth','清理过期日志','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"清理过期日志\", \"method\": \"POST\", \"timestamp\": \"2025-11-06T00:43:02.194874+00:00\", \"status_code\": 404}','192.168.211.234','2025-11-06 00:43:02.194874',NULL),(67,'INFO','system','系统配置更新','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"系统配置更新\", \"method\": \"POST\", \"timestamp\": \"2025-11-02T08:13:02.195691+00:00\", \"status_code\": 400}','192.168.176.44','2025-11-02 08:13:02.195691',1),(68,'WARNING','api','用户登出','{\"test\": true, \"action\": \"用户登出\", \"timestamp\": \"2025-11-04T21:37:02.196955+00:00\"}','192.168.131.208','2025-11-04 21:37:02.196955',1),(69,'ERROR','api','内容审核拒绝','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"内容审核拒绝\", \"method\": \"POST\", \"timestamp\": \"2025-11-05T03:08:02.197929+00:00\", \"status_code\": 400}','192.168.51.202','2025-11-05 03:08:02.197929',NULL),(70,'WARNING','backup','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-10-31T17:55:02.199005+00:00\"}','192.168.200.239','2025-10-31 17:55:02.199005',NULL),(71,'DEBUG','content','创建新内容','{\"test\": true, \"action\": \"创建新内容\", \"timestamp\": \"2025-11-05T16:57:02.199849+00:00\"}','192.168.221.37','2025-11-05 16:57:02.199849',1),(72,'ERROR','api','用户登出','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"用户登出\", \"method\": \"POST\", \"timestamp\": \"2025-11-02T22:01:02.201175+00:00\", \"status_code\": 201}','192.168.230.1','2025-11-02 22:01:02.201175',NULL),(73,'CRITICAL','api','封禁用户','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"封禁用户\", \"method\": \"PUT\", \"timestamp\": \"2025-11-02T10:49:02.202052+00:00\", \"status_code\": 404}','192.168.8.195','2025-11-02 10:49:02.202052',NULL),(74,'DEBUG','system','数据库备份开始','{\"test\": true, \"action\": \"数据库备份开始\", \"timestamp\": \"2025-11-04T04:44:02.202907+00:00\"}','192.168.3.146','2025-11-04 04:44:02.202907',1),(75,'DEBUG','system','用户登出','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"用户登出\", \"method\": \"PUT\", \"timestamp\": \"2025-10-31T03:15:02.203693+00:00\", \"status_code\": 400}','192.168.186.214','2025-10-31 03:15:02.203693',1),(76,'ERROR','user','清理过期日志','{\"test\": true, \"action\": \"清理过期日志\", \"timestamp\": \"2025-10-31T17:54:02.204445+00:00\"}','192.168.241.109','2025-10-31 17:54:02.204445',NULL),(77,'WARNING','backup','内容审核通过','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"内容审核通过\", \"method\": \"POST\", \"timestamp\": \"2025-10-31T17:19:02.205444+00:00\", \"status_code\": 204}','192.168.126.6','2025-10-31 17:19:02.205444',NULL),(78,'ERROR','system','内容审核拒绝','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"内容审核拒绝\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-02T05:22:02.206531+00:00\", \"status_code\": 200}','192.168.121.176','2025-11-02 05:22:02.206531',1),(79,'CRITICAL','system','数据库备份完成','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"数据库备份完成\", \"method\": \"POST\", \"timestamp\": \"2025-10-31T21:49:02.207349+00:00\", \"status_code\": 201}','192.168.69.213','2025-10-31 21:49:02.207349',1),(80,'ERROR','api','创建新内容','{\"path\": \"/api/v1/api/\", \"test\": true, \"action\": \"创建新内容\", \"method\": \"GET\", \"timestamp\": \"2025-10-31T08:39:02.208489+00:00\", \"status_code\": 200}','192.168.53.35','2025-10-31 08:39:02.208489',1),(81,'ERROR','auth','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-11-07T14:22:02.209727+00:00\"}','192.168.141.176','2025-11-07 14:22:02.209727',1),(82,'INFO','auth','更新配置','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"更新配置\", \"method\": \"PUT\", \"timestamp\": \"2025-11-04T07:19:02.210543+00:00\", \"status_code\": 404}','192.168.118.82','2025-11-04 07:19:02.210543',1),(83,'ERROR','system','密码重置请求','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"密码重置请求\", \"method\": \"GET\", \"timestamp\": \"2025-10-31T01:42:02.211501+00:00\", \"status_code\": 400}','192.168.241.149','2025-10-31 01:42:02.211501',1),(84,'ERROR','backup','封禁用户','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"封禁用户\", \"method\": \"PUT\", \"timestamp\": \"2025-11-04T05:46:02.212175+00:00\", \"status_code\": 500}','192.168.133.103','2025-11-04 05:46:02.212175',1),(85,'CRITICAL','backup','内容审核拒绝','{\"path\": \"/api/v1/backup/\", \"test\": true, \"action\": \"内容审核拒绝\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-04T04:09:02.213106+00:00\", \"status_code\": 404}','192.168.91.174','2025-11-04 04:09:02.213106',NULL),(86,'DEBUG','api','用户注册','{\"test\": true, \"action\": \"用户注册\", \"timestamp\": \"2025-11-07T08:21:02.214066+00:00\"}','192.168.126.44','2025-11-07 08:21:02.214066',NULL),(87,'WARNING','content','密码重置请求','{\"test\": true, \"action\": \"密码重置请求\", \"timestamp\": \"2025-10-30T17:41:02.215195+00:00\"}','192.168.38.35','2025-10-30 17:41:02.215195',1),(88,'CRITICAL','system','清理过期日志','{\"test\": true, \"action\": \"清理过期日志\", \"timestamp\": \"2025-11-01T15:52:02.216081+00:00\"}','192.168.189.218','2025-11-01 15:52:02.216081',1),(89,'INFO','user','更新配置','{\"path\": \"/api/v1/user/\", \"test\": true, \"action\": \"更新配置\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-06T11:43:02.216875+00:00\", \"status_code\": 500}','192.168.119.31','2025-11-06 11:43:02.216875',1),(90,'ERROR','user','密码重置请求','{\"path\": \"/api/v1/user/\", \"test\": true, \"action\": \"密码重置请求\", \"method\": \"POST\", \"timestamp\": \"2025-11-02T07:51:02.217611+00:00\", \"status_code\": 204}','192.168.116.89','2025-11-02 07:51:02.217611',1),(91,'CRITICAL','content','系统配置更新','{\"test\": true, \"action\": \"系统配置更新\", \"timestamp\": \"2025-10-30T22:58:02.218222+00:00\"}','192.168.120.6','2025-10-30 22:58:02.218222',1),(92,'INFO','content','清理过期日志','{\"path\": \"/api/v1/content/\", \"test\": true, \"action\": \"清理过期日志\", \"method\": \"PUT\", \"timestamp\": \"2025-11-01T01:55:02.218823+00:00\", \"status_code\": 200}','192.168.125.29','2025-11-01 01:55:02.218823',1),(93,'WARNING','system','清理过期日志','{\"test\": true, \"action\": \"清理过期日志\", \"timestamp\": \"2025-11-05T00:45:02.219485+00:00\"}','192.168.61.127','2025-11-05 00:45:02.219485',1),(94,'WARNING','auth','数据库备份完成','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"数据库备份完成\", \"method\": \"POST\", \"timestamp\": \"2025-11-03T20:34:02.220096+00:00\", \"status_code\": 201}','192.168.123.157','2025-11-03 20:34:02.220096',1),(95,'DEBUG','backup','内容审核拒绝','{\"test\": true, \"action\": \"内容审核拒绝\", \"timestamp\": \"2025-11-01T15:22:02.221198+00:00\"}','192.168.23.226','2025-11-01 15:22:02.221198',1),(96,'INFO','system','用户登录成功','{\"path\": \"/api/v1/system/\", \"test\": true, \"action\": \"用户登录成功\", \"method\": \"DELETE\", \"timestamp\": \"2025-10-31T15:15:02.221793+00:00\", \"status_code\": 404}','192.168.26.244','2025-10-31 15:15:02.221793',NULL),(97,'CRITICAL','user','用户登出','{\"path\": \"/api/v1/user/\", \"test\": true, \"action\": \"用户登出\", \"method\": \"DELETE\", \"timestamp\": \"2025-11-07T10:17:02.222909+00:00\", \"status_code\": 200}','192.168.49.63','2025-11-07 10:17:02.222909',NULL),(98,'WARNING','user','内容审核拒绝','{\"test\": true, \"action\": \"内容审核拒绝\", \"timestamp\": \"2025-11-02T12:07:02.223566+00:00\"}','192.168.61.146','2025-11-02 12:07:02.223566',1),(99,'WARNING','user','更新配置','{\"path\": \"/api/v1/user/\", \"test\": true, \"action\": \"更新配置\", \"method\": \"PUT\", \"timestamp\": \"2025-11-05T22:04:02.224234+00:00\", \"status_code\": 500}','192.168.152.79','2025-11-05 22:04:02.224234',1),(100,'ERROR','auth','创建新内容','{\"path\": \"/api/v1/auth/\", \"test\": true, \"action\": \"创建新内容\", \"method\": \"GET\", \"timestamp\": \"2025-11-04T00:10:02.225149+00:00\", \"status_code\": 200}','192.168.216.190','2025-11-04 00:10:02.225149',1),(101,'INFO','system','系统启动完成','{\"version\": \"1.0.0\", \"startup_time\": \"2025-11-07T16:41:37.387879+00:00\"}',NULL,'2025-11-07 16:41:37.388092',NULL),(102,'INFO','auth','管理员登录成功: admin','{\"ip\": \"127.0.0.1\", \"role\": \"admin\", \"username\": \"admin\"}',NULL,'2025-11-07 16:41:37.389912',1),(103,'INFO','system','系统配置已加载','{\"config_count\": 19}',NULL,'2025-11-07 16:41:37.390731',NULL),(104,'INFO','system','中间件已启用: SystemLogMiddleware','{\"middleware\": \"SystemLogMiddleware\"}',NULL,'2025-11-07 16:41:37.391115',NULL),(105,'DEBUG','api','API文档已生成','{\"endpoints\": 50}',NULL,'2025-11-07 16:41:37.391449',NULL),(106,'INFO','api','GET /api/v1/system/config/ - 200 (0.105s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.10506486892700195, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:41:47.805746',1),(107,'INFO','api','GET /api/v1/system/config/ - 200 (0.065s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.06508374214172363, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:41:58.812155',1),(108,'INFO','api','GET /api/v1/system/config/ - 200 (0.096s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.0961167812347412, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:42:59.457187',1),(109,'INFO','api','GET /api/v1/system/config/ - 200 (0.060s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.05972599983215332, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:43:12.786969',1),(110,'INFO','api','GET /api/v1/system/config/ - 200 (0.051s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.05080819129943848, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:45:41.643540',1),(111,'INFO','api','GET /api/v1/system/config/ - 200 (0.013s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.012969970703125, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:48:37.800174',1),(112,'WARNING','api','POST /api/v1/system/backup/create_backup/ - 400 (0.018s)','{\"path\": \"/api/v1/system/backup/create_backup/\", \"method\": \"POST\", \"duration\": 0.018347978591918945, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 400}','127.0.0.1','2025-11-07 16:48:42.060410',1),(113,'ERROR','backup','数据库备份失败: 备份执行失败: mysqldump: [Warning] Using a password on the command line interface can be insecure.\n','{\"error\": \"备份执行失败: mysqldump: [Warning] Using a password on the command line interface can be insecure.\\n\"}',NULL,'2025-11-07 16:51:03.008266',NULL),(114,'INFO','backup','数据库备份成功: backup_20251108_005255.sql.gz','{\"file_path\": \"/Volumes/GT/dijango400/backend/backups/backup_20251108_005255.sql.gz\", \"file_size\": 21343}',NULL,'2025-11-07 16:52:55.339215',NULL),(115,'INFO','api','GET /api/v1/system/config/ - 200 (0.074s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.07356500625610352, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:54:10.903573',1),(116,'INFO','backup','数据库备份成功: backup_20251108_005441.sql.gz','{\"file_path\": \"/Volumes/GT/dijango400/backend/backups/backup_20251108_005441.sql.gz\", \"file_size\": 21568}',NULL,'2025-11-07 16:54:42.041506',NULL),(117,'INFO','api','GET /api/v1/system/config/ - 200 (0.021s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.021154165267944336, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 16:56:29.796929',1),(118,'INFO','backup','数据库备份成功: backup_20251108_005632.sql.gz','{\"file_path\": \"/Volumes/GT/dijango400/backend/backups/backup_20251108_005632.sql.gz\", \"file_size\": 21687}',NULL,'2025-11-07 16:56:32.206465',NULL),(119,'INFO','backup','数据库备份成功','{\"duration\": 0.140644, \"operator\": \"admin\", \"backup_id\": 5, \"file_path\": \"/Volumes/GT/dijango400/backend/backups/backup_20251108_005632.sql.gz\", \"file_size\": 21687}',NULL,'2025-11-07 16:56:32.208185',1),(120,'INFO','api','POST /api/v1/system/backup/create_backup/ - 200 (0.159s)','{\"path\": \"/api/v1/system/backup/create_backup/\", \"method\": \"POST\", \"duration\": 0.15862417221069336, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200}','127.0.0.1','2025-11-07 16:56:32.209494',1),(121,'INFO','api','GET /api/v1/system/backup/ - 200 (0.006s)','{\"path\": \"/api/v1/system/backup/\", \"method\": \"GET\", \"duration\": 0.005789995193481445, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"50\"]}}','127.0.0.1','2025-11-07 16:56:32.225102',1),(122,'INFO','api','GET /api/v1/system/config/ - 200 (0.023s)','{\"path\": \"/api/v1/system/config/\", \"method\": \"GET\", \"duration\": 0.022684335708618164, \"user_agent\": \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36\", \"status_code\": 200, \"query_params\": {\"page_size\": [\"1000\"]}}','127.0.0.1','2025-11-07 17:00:29.672105',1);
/*!40000 ALTER TABLE `sys_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'多人在线','支持多人同时在线游戏','2025-11-07 02:23:49.824817'),(2,'单机','单人游戏体验','2025-11-07 02:23:49.840148'),(3,'竞技','竞技对战类游戏','2025-11-07 02:23:49.843231'),(4,'休闲','轻松休闲娱乐','2025-11-07 02:23:49.848696'),(5,'策略','需要策略思考','2025-11-07 02:23:49.851036'),(6,'冒险','探索冒险类','2025-11-07 02:23:49.857134'),(7,'射击','射击类游戏','2025-11-07 02:23:49.862274'),(8,'角色扮演','RPG角色扮演','2025-11-07 02:23:49.869456'),(9,'卡牌','卡牌收集类','2025-11-07 02:23:49.876752'),(10,'模拟经营','模拟经营类','2025-11-07 02:23:49.884438'),(11,'开放世界','开放世界探索','2025-11-07 02:23:49.896452'),(12,'二次元','二次元风格','2025-11-07 02:23:49.901837'),(13,'3D','3D画面','2025-11-07 02:23:49.910285'),(14,'像素','像素风格','2025-11-07 02:23:49.918134'),(15,'回合制','回合制战斗','2025-11-07 02:23:49.920940');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic_follows`
--

DROP TABLE IF EXISTS `topic_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topic_follows` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `topic_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `topic_follows_user_id_topic_id_47e5d082_uniq` (`user_id`,`topic_id`),
  KEY `topic_follo_user_id_b23ffc_idx` (`user_id`,`created_at` DESC),
  KEY `topic_follo_topic_i_fad26f_idx` (`topic_id`,`created_at` DESC),
  CONSTRAINT `topic_follows_topic_id_46c3cd41_fk_topics_id` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`),
  CONSTRAINT `topic_follows_user_id_212075b2_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic_follows`
--

LOCK TABLES `topic_follows` WRITE;
/*!40000 ALTER TABLE `topic_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `heat` double NOT NULL,
  `follow_count` int NOT NULL,
  `post_count` int NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `topics_heat_28e96dfc` (`heat`),
  KEY `topics_heat_a35fa3_idx` (`heat` DESC),
  KEY `topics_post_co_96a189_idx` (`post_count` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_interests`
--

DROP TABLE IF EXISTS `user_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_interests` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `weight` double NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `tag_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_interests_user_id_tag_id_bae33d2c_uniq` (`user_id`,`tag_id`),
  KEY `user_interests_tag_id_9b7b920e_fk_tags_id` (`tag_id`),
  KEY `user_intere_user_id_222a9e_idx` (`user_id`,`weight` DESC),
  CONSTRAINT `user_interests_tag_id_9b7b920e_fk_tags_id` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`),
  CONSTRAINT `user_interests_user_id_62782381_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_interests`
--

LOCK TABLES `user_interests` WRITE;
/*!40000 ALTER TABLE `user_interests` DISABLE KEYS */;
INSERT INTO `user_interests` VALUES (5,1,'2025-11-07 14:37:07.387271',13,2),(6,1,'2025-11-07 14:37:07.387332',1,2),(7,1,'2025-11-07 14:37:07.387349',3,2);
/*!40000 ALTER TABLE `user_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_operations`
--

DROP TABLE IF EXISTS `user_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_operations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` char(39) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_operations_created_at_cffea0e7` (`created_at`),
  KEY `user_operat_user_id_629d98_idx` (`user_id`,`created_at` DESC),
  CONSTRAINT `user_operations_user_id_22c7cbdf_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_operations`
--

LOCK TABLES `user_operations` WRITE;
/*!40000 ALTER TABLE `user_operations` DISABLE KEYS */;
INSERT INTO `user_operations` VALUES (1,'状态变更: 封禁 - 原因: 2','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-07 16:04:49.339330',3),(2,'状态变更: 正常','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-07 16:12:14.272534',3),(3,'状态变更: 封禁 - 原因: 22','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-07 16:12:22.270948',3),(4,'状态变更: 正常','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-07 16:12:47.000770',3);
/*!40000 ALTER TABLE `user_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `register_time` datetime(6) NOT NULL,
  `last_login_time` datetime(6) DEFAULT NULL,
  `avatar` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `phone` (`phone`),
  KEY `users_usernam_baeb4b_idx` (`username`),
  KEY `users_role_0ace22_idx` (`role`),
  KEY `users_status_9ca66f_idx` (`status`),
  KEY `users_registe_22e2d4_idx` (`register_time` DESC),
  KEY `users_role_f0571928` (`role`),
  KEY `users_status_e50cb8ed` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'pbkdf2_sha256$600000$VpDh5FHi5DUmfnUgCuCRgT$/TA39ZrqVPkh2kb0jjXaL65M+qLiwqxF69Jbliod4Iw=','2025-11-07 16:02:51.571085',1,'admin','','','admin@example.com',1,1,'2025-11-06 07:51:55.532473',NULL,'admin',1,'2025-11-06 07:51:55.578316',NULL,'',''),(2,'pbkdf2_sha256$600000$0uSy7z53Yn84p4uox7s33g$u/KndFSm6s5UB2Af/seQhzvdrDUcUXt+JlJp9Ve3Tw4=','2025-11-07 15:14:48.372549',0,'leia','','','2@gmail.com',0,1,'2025-11-07 13:12:07.788043',NULL,'player',1,'2025-11-07 13:12:07.788576',NULL,'',''),(3,'pbkdf2_sha256$600000$aAbt5XoSOvNwIb0FXRwcks$u07Wc1EOryXBNttf2PmT1tf4Q9VzbamdBk158zUce7M=','2025-11-07 16:12:16.485504',0,'wyn','','','2@gmail.com',0,1,'2025-11-07 15:40:01.416518',NULL,'creator',1,'2025-11-07 15:40:01.416707',NULL,'','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_user_id_group_id_fc7788e8_uniq` (`user_id`,`group_id`),
  KEY `users_groups_group_id_2f3517aa_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_groups_group_id_2f3517aa_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_groups_user_id_f500bee5_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_user_permissions`
--

DROP TABLE IF EXISTS `users_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_permissions_user_id_permission_id_3b86cbdf_uniq` (`user_id`,`permission_id`),
  KEY `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_permissions_user_id_92473840_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_user_permissions`
--

LOCK TABLES `users_user_permissions` WRITE;
/*!40000 ALTER TABLE `users_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-08  1:00:34
